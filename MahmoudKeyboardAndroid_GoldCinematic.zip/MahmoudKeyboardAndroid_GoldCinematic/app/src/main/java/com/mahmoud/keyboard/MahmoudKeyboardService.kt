package com.mahmoud.keyboard

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.media.AudioManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

class MahmoudKeyboardService : InputMethodService() {
    private var root: LinearLayout? = null
    private val rows = listOf(
        listOf("ض","ص","ث","ق","ف","غ","ع","ه","خ","ح","ج"),
        listOf("ش","س","ي","ب","ل","ا","ت","ن","م","ك","ط"),
        listOf("ئ","ء","ؤ","ر","لا","ى","ة","و","ز","ظ","د"),
        listOf("⌫","،",".","؟","!","مسافة","↵")
    )
    override fun onCreateInputView(): View {
        root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(7,5,7,9); setBackgroundColor(Color.rgb(6,7,9)) }
        addBanner(); rows.forEach { addRow(it) }; addBottomBar(); return root!!
    }
    private fun addBanner() {
        val frame=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER; setPadding(3,2,3,4); background=GradientDrawable().apply { cornerRadius=18f; setStroke(2,Color.rgb(205,165,75)); setColor(Color.rgb(12,13,16)) } }
        val image=ImageView(this).apply { setImageResource(R.drawable.mahmoud_banner); scaleType=ImageView.ScaleType.CENTER_CROP }
        frame.addView(image,LinearLayout.LayoutParams(-1,67))
        frame.addView(TextView(this).apply { text="♛  محمود أبو الهدى  •  m__515__ma"; setTextColor(Color.rgb(235,198,112)); textSize=14f; gravity=Gravity.CENTER },LinearLayout.LayoutParams(-1,29))
        root?.addView(frame,LinearLayout.LayoutParams(-1,99))
    }
    private fun addRow(keys:List<String>) {
        val row=LinearLayout(this).apply { orientation=LinearLayout.HORIZONTAL; gravity=Gravity.CENTER }
        keys.forEach { key ->
            val b=Button(this).apply { text=key; textSize=if(key=="مسافة")12f else 17f; setTextColor(if(key=="⌫"||key=="↵")Color.rgb(28,20,9) else Color.WHITE); background=resources.getDrawable(if(key=="⌫"||key=="↵")R.drawable.gold_key_bg else R.drawable.key_bg,theme); stateListAnimator=null; isAllCaps=false; setPadding(0,0,0,0); setOnClickListener{press(key,this)} }
            val weight=if(key=="مسافة")2.2f else 1f; val lp=LinearLayout.LayoutParams(0,50,weight); lp.setMargins(2,3,2,3); row.addView(b,lp)
        }; root?.addView(row)
    }
    private fun addBottomBar(){
        val bar=LinearLayout(this).apply{gravity=Gravity.CENTER;setPadding(4,2,4,2);background=GradientDrawable().apply{cornerRadius=22f;setColor(Color.rgb(11,12,15));setStroke(1,Color.rgb(105,79,34))}}
        listOf("⚙ الإعدادات","🎨 الثيمات","🔊 الأصوات","♛ مميز").forEach{label->bar.addView(TextView(this).apply{text=label;textSize=12f;setTextColor(Color.rgb(220,184,99));gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,42,1f))}
        root?.addView(bar,LinearLayout.LayoutParams(-1,48))
    }
    private fun press(key:String,view:View){
        view.animate().scaleX(.88f).scaleY(.88f).setDuration(55).withEndAction{view.animate().scaleX(1f).scaleY(1f).setDuration(130).start()}.start()
        val v=getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if(android.os.Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(18,VibrationEffect.DEFAULT_AMPLITUDE)) else @Suppress("DEPRECATION") v.vibrate(18)
        val audio=getSystemService(Context.AUDIO_SERVICE) as AudioManager
        audio.playSoundEffect(if(key=="⌫"||key=="↵")AudioManager.FX_KEYPRESS_DELETE else AudioManager.FX_KEYPRESS_STANDARD)
        val ic:InputConnection=currentInputConnection?:return
        when(key){"⌫"->ic.deleteSurroundingText(1,0);"↵"->ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN,android.view.KeyEvent.KEYCODE_ENTER));"مسافة"->ic.commitText(" ",1);else->ic.commitText(key,1)}
    }
}
